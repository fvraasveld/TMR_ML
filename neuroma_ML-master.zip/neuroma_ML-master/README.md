# neuroma TMR outcome prediction model
- Written by Zihe (Alex) Zhang
- alexzhang.hms@gmail.com

This GitHub repository hosts the code used for data analysis and modeling in the manuscript "Machine Learning Approach to Predict Pain Outcomes Following Primary and Secondary Targeted Muscle Reinnervation in Amputees."
